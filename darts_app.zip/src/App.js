import React, { useState } from "react";

let deferredPrompt;
window.addEventListener("beforeinstallprompt", (e) => {
  e.preventDefault();
  deferredPrompt = e;
});

const checkoutMap = {
  170: "T20 T20 Bull",
  160: "T20 T20 D20",
  100: "T20 D20",
  60: "20 D20",
  40: "D20",
  32: "D16"
};

const scoreOptions = [26, 41, 60, 100, 140, 180];

const getAIScore = (level, remaining) => {
  let accuracy = level === "easy" ? 0.3 : level === "medium" ? 0.6 : 0.85;

  if (remaining <= 170 && remaining % 2 === 0 && Math.random() < accuracy) {
    return remaining;
  }

  return scoreOptions[Math.floor(Math.random() * scoreOptions.length)];
};

export default function App() {
  const [playerScore, setPlayerScore] = useState(501);
  const [aiScore, setAiScore] = useState(501);
  const [input, setInput] = useState("");
  const [level, setLevel] = useState("medium");

  const handleTurn = () => {
    const score = parseInt(input);
    if (isNaN(score)) return;

    let newPlayer = playerScore - score;
    if (newPlayer < 0 || newPlayer === 1 || (newPlayer === 0 && score % 2 !== 0)) {
      newPlayer = playerScore;
    }

    const aiThrow = getAIScore(level, aiScore);
    let newAI = aiScore - aiThrow;
    if (newAI < 0 || newAI === 1 || (newAI === 0 && aiThrow % 2 !== 0)) {
      newAI = aiScore;
    }

    setPlayerScore(newPlayer);
    setAiScore(newAI);
    setInput("");
  };

  const installApp = async () => {
    if (!deferredPrompt) return;
    deferredPrompt.prompt();
    await deferredPrompt.userChoice;
    deferredPrompt = null;
  };

  return (
    <div style={{ padding: 20 }}>
      <h1>🎯 Darts 501</h1>
      <p>Jij: {playerScore}</p>
      <p>AI: {aiScore}</p>
      <p>Tip: {checkoutMap[playerScore] || "-"}</p>

      <input
        value={input}
        onChange={(e) => setInput(e.target.value)}
        placeholder="Score"
      />
      <button onClick={handleTurn}>Gooi</button>

      <div>
        <button onClick={() => setLevel("easy")}>Easy</button>
        <button onClick={() => setLevel("medium")}>Medium</button>
        <button onClick={() => setLevel("hard")}>Hard</button>
      </div>

      <button onClick={installApp}>📲 Installeer App</button>
    </div>
  );
}
